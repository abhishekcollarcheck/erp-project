import { Op } from "sequelize";

import { Employee } from "../../database/models/Employee";
import { Shift } from "../../database/models/Shift";
import { AttendanceRegularization } from "../../database/models/AttendanceRegularization";

import {
  attendanceMSSQLService,
  MSSQLAttendanceRow,
} from "./attendance.mssql.service";

import {
  trakolaService,
  TrakolaAttendanceRow,
} from "./trackola.service";

import { AppError } from "../../middleware/errorHandler.middleware";

import {
  evaluateAttendanceStatus,
  FinalAttendanceStatus,
  AppliedLeaveDetails,
} from "./shift-rule-evaluator.service";

import { holidayService } from "./holiday.service";
import { isWeeklyOff } from "./weekly-off.util";

import { LeaveRequest, LeaveType } from "@/database/models";
import { EmployeeLeaveBalance } from "@/database/models/LeaveModels";
import { resolveLeaveContextForDate } from "./leaveResolver.services";

export type CombinedDayStatus =
  | "Present"
  | "Incomplete"
  | "No Punches";

export type AttendanceSourceTag =
  | "Biometric"
  | "Trakola"
  | "Regularized";

interface ApprovedRegularizationRow {
  date: string;
  check_in: string | null;
  check_out: string | null;
}

export interface CombinedAttendanceRow {
  date: string;
  check_in: string | null;
  check_out: string | null;
  working_hours: number | null;
  sources: AttendanceSourceTag[];
  isRegularized: boolean;
  status: CombinedDayStatus;
  finalStatus: FinalAttendanceStatus | null;
  matchedRule: string | null;
  lateMinutes: number | null;
  punch_count: number;
  scenarioDescription?: string;
  leaveType?: string | null;
  leavePosition?: string | null;
  leaveApproved?: boolean;
  availableLeaveDays?: number;
}

export class AttendanceCombinedService {
  /**
   * Combined attendance for ONE employee over a date range.
   *
   * IMPORTANT:
   * Every date between startDate and endDate is included,
   * even when there is no biometric, Trakola, or regularization data.
   */
  async getCombinedForEmployee(
    employeeId: number,
    startDate: string,
    endDate: string,
    companyId: number,
  ): Promise<CombinedAttendanceRow[]> {
    // ============================================================
    // 1. GET EMPLOYEE
    // ============================================================

    const employee = await Employee.findOne({
      where: {
        id: employeeId,
      },
      attributes: [
        "employee_code",
        "first_name",
        "last_name",
        "shift_id",
        "grace_minutes",
        "saturday_off",
      ],
    });

    if (!employee) {
      throw new AppError("Employee not found", 404);
    }

    // ============================================================
    // 2. FETCH ALL ATTENDANCE-RELATED DATA
    // ============================================================

    const [
      bioRows,
      trakRows,
      holidayMap,
      regRows,
      leaveRequests,
    ] = await Promise.all([
      // ----------------------------------------------------------
      // Biometric
      // ----------------------------------------------------------

      attendanceMSSQLService.getAttendanceByDate(
        startDate,
        endDate,
        employee.employee_code,
      ),

      // ----------------------------------------------------------
      // Trakola
      // ----------------------------------------------------------

      trakolaService
        .getNormalizedAttendance(
          startDate,
          endDate,
          employee.employee_code,
          `${employee.first_name} ${employee.last_name}`,
        )
        .catch((error: any) => {
          console.error(
            `[attendance-combined] Trakola fetch failed for employee ${employeeId} ` +
              `(${startDate} to ${endDate}). ` +
              `Continuing with Biometric-only data.`,
            error?.message,
          );

          return [];
        }),

      // ----------------------------------------------------------
      // Holidays
      // ----------------------------------------------------------

      holidayService.getHolidaysInRange(
        startDate,
        endDate,
        companyId,
      ),

      // ----------------------------------------------------------
      // Approved regularizations
      // ----------------------------------------------------------

      this.getApprovedRegularizations(
        employeeId,
        startDate,
        endDate,
      ),

      // ----------------------------------------------------------
      // Approved leaves
      // ----------------------------------------------------------

      LeaveRequest.findAll({
        where: {
          employee_id: employeeId,
          status: "Approved",

          from_date: {
            [Op.lte]: endDate,
          },

          to_date: {
            [Op.gte]: startDate,
          },
        },
      }),
    ]);

    // ============================================================
    // 3. GET LEAVE TYPES
    // ============================================================

    const leaveTypeIds = [
      ...new Set(
        leaveRequests
          .map((request: any) => request.leave_type_id)
          .filter(
            (id) => id !== null && id !== undefined,
          ),
      ),
    ];

    const leaveTypes =
      leaveTypeIds.length > 0
        ? await LeaveType.findAll({
            where: {
              id: {
                [Op.in]: leaveTypeIds,
              },
            },
          })
        : [];

    const leaveTypesById = new Map(
      leaveTypes.map((leaveType: any) => [
        leaveType.id,
        leaveType,
      ]),
    );

    // ============================================================
    // 4. GET EMPLOYEE LEAVE BALANCES
    // ============================================================

    const leaveBalances = await EmployeeLeaveBalance.findAll({
      where: {
        employee_id: employeeId,
      },
    });

    // ============================================================
    // 5. MERGE BIOMETRIC + TRAKOLA + REGULARIZATION
    //
    // IMPORTANT:
    // mergeByDate() creates ALL dates between startDate/endDate.
    // Therefore a completely missing attendance day is preserved.
    // ============================================================

    const merged = this.mergeByDate(
      bioRows,
      trakRows,
      regRows,
      startDate,
      endDate,
    );

    // ============================================================
    // 6. GET SHIFT
    // ============================================================

    let shift: Shift | null = null;

    if (employee.shift_id) {
      shift = await Shift.findByPk(employee.shift_id);
    }

    // ============================================================
    // 7. APPLY DAY TYPE + LEAVE + ATTENDANCE RULES
    // ============================================================

    return merged.map((row) => {
      // ----------------------------------------------------------
      // Resolve leave for THIS particular date
      // ----------------------------------------------------------

      const leaveContext = resolveLeaveContextForDate(
        row.date,
        leaveRequests,
        leaveTypesById,
        leaveBalances,
      );

      // ----------------------------------------------------------
      // Check holiday
      // ----------------------------------------------------------

      const holidayName = holidayMap.get(row.date);
      const isHoliday = Boolean(holidayName);

      // ----------------------------------------------------------
      // Check weekly off
      // ----------------------------------------------------------

      const weeklyOff = isWeeklyOff(
        row.date,
        employee.saturday_off,
      );

      const isWeekOff = weeklyOff.isOff;

      // ----------------------------------------------------------
      // Common leave information
      // ----------------------------------------------------------

      const leaveType =
        leaveContext.appliedLeave?.type ?? null;

      const leavePosition =
        leaveContext.appliedLeave?.position ?? null;

      const leaveApproved =
        leaveContext.appliedLeave?.approved ?? false;

      const availableLeaveDays =
        leaveContext.availableLeaveDays;

      // ==========================================================
      // HOLIDAY
      // ==========================================================

      if (isHoliday) {
        return {
          ...row,

          finalStatus:
            "HOLIDAY" as FinalAttendanceStatus,

          matchedRule: holidayName
            ? `HOLIDAY:${holidayName}`
            : "HOLIDAY",

          lateMinutes: 0,

          leaveType,
          leavePosition,
          leaveApproved,
          availableLeaveDays,
        };
      }

      // ==========================================================
      // WEEKLY OFF
      // ==========================================================

      if (isWeekOff) {
        return {
          ...row,

          finalStatus:
            "WEEK_OFF" as FinalAttendanceStatus,

          matchedRule:
            weeklyOff.reason ?? "WEEKLY_OFF",

          lateMinutes: 0,

          leaveType,
          leavePosition,
          leaveApproved,
          availableLeaveDays,
        };
      }

      // ==========================================================
      // NO SHIFT
      // ==========================================================

      if (!shift) {
        return {
          ...row,

          finalStatus: null,
          matchedRule: null,
          lateMinutes: null,

          leaveType,
          leavePosition,
          leaveApproved,
          availableLeaveDays,
        };
      }

      // ==========================================================
      // NORMAL ATTENDANCE EVALUATION
      // ==========================================================

      const result = evaluateAttendanceStatus(
        row,
        shift,
        {
          graceMinutes:
            employee.grace_minutes ?? 15,

          isWeekOff: false,

          isHoliday: false,

          appliedLeave:
            leaveContext.appliedLeave,

          availableLeaveDays:
            leaveContext.availableLeaveDays,
        },
      );

      // ==========================================================
      // FINAL RESPONSE
      // ==========================================================

      return {
        ...row,

        finalStatus: result.status,

        matchedRule: result.matchedRule,

        lateMinutes: result.lateMinutes,

        leaveType,
        leavePosition,
        leaveApproved,
        availableLeaveDays,
      };
    });
  }

  // =====================================================================
  // GET APPROVED REGULARIZATIONS
  // =====================================================================

  private async getApprovedRegularizations(
    employeeId: number,
    startDate: string,
    endDate: string,
  ): Promise<ApprovedRegularizationRow[]> {
    const rows =
      await AttendanceRegularization.findAll({
        where: {
          employee_id: employeeId,

          status: "Approved",

          date: {
            [Op.between]: [
              startDate,
              endDate,
            ],
          },
        },

        attributes: [
          "date",
          "requested_check_in",
          "requested_check_out",
        ],
      });

    return rows.map((row: any) => ({
      date: row.date,

      check_in:
        row.requested_check_in ?? null,

      check_out:
        row.requested_check_out ?? null,
    }));
  }

  // =====================================================================
  // GENERATE EVERY DATE IN RANGE
  // =====================================================================

  private generateDateRange(
    startDate: string,
    endDate: string,
  ): string[] {
    const dates: string[] = [];

    const current = new Date(
      `${startDate}T00:00:00`,
    );

    const end = new Date(
      `${endDate}T00:00:00`,
    );

    while (current <= end) {
      const year = current.getFullYear();
      const month = String(
        current.getMonth() + 1,
      ).padStart(2, "0");

      const day = String(
        current.getDate(),
      ).padStart(2, "0");

      dates.push(
        `${year}-${month}-${day}`,
      );

      current.setDate(
        current.getDate() + 1,
      );
    }

    return dates;
  }

  // =====================================================================
  // MERGE BIOMETRIC + TRAKOLA + REGULARIZATION
  // =====================================================================

  private mergeByDate(
    bioRows: MSSQLAttendanceRow[],
    trakRows: TrakolaAttendanceRow[],
    regRows: ApprovedRegularizationRow[],
    startDate: string,
    endDate: string,
  ): CombinedAttendanceRow[] {
    const byDate = new Map<
      string,
      {
        bio?: MSSQLAttendanceRow;
        trak?: TrakolaAttendanceRow;
        reg?: ApprovedRegularizationRow;
      }
    >();

    // ============================================================
    // IMPORTANT:
    // Initialize ALL dates first.
    //
    // This is the main fix for missing absent dates.
    // ============================================================

    const allDates = this.generateDateRange(
      startDate,
      endDate,
    );

    for (const date of allDates) {
      byDate.set(date, {});
    }

    // ============================================================
    // BIOMETRIC
    // ============================================================

    for (const row of bioRows) {
      const existing = byDate.get(row.date);

      byDate.set(row.date, {
        ...existing,
        bio: row,
      });
    }

    // ============================================================
    // TRAKOLA
    // ============================================================

    for (const row of trakRows) {
      const existing = byDate.get(row.date);

      byDate.set(row.date, {
        ...existing,
        trak: row,
      });
    }

    // ============================================================
    // REGULARIZATION
    // ============================================================

    for (const row of regRows) {
      const existing = byDate.get(row.date);

      byDate.set(row.date, {
        ...existing,
        reg: row,
      });
    }

    // ============================================================
    // BUILD RESULT
    // ============================================================

    const result: CombinedAttendanceRow[] = [];

    for (const [
      date,
      { bio, trak, reg },
    ] of byDate.entries()) {
      // ----------------------------------------------------------
      // Punch count
      // ----------------------------------------------------------

      const punch_count =
        (bio?.punch_count ?? 0) +
        (trak?.punch_count ?? 0);

      // ----------------------------------------------------------
      // Check-ins
      // ----------------------------------------------------------

      const checkIns = [
        bio?.check_in,
        trak?.check_in,
      ].filter(
        (
          value,
        ): value is string =>
          Boolean(value),
      );

      // ----------------------------------------------------------
      // Check-outs
      // ----------------------------------------------------------

      const checkOuts = [
        bio?.check_out,
        trak?.check_out,
      ].filter(
        (
          value,
        ): value is string =>
          Boolean(value),
      );

      // ----------------------------------------------------------
      // Earliest check-in
      // ----------------------------------------------------------

      const mergedCheckIn =
        checkIns.length > 0
          ? [...checkIns].sort()[0]
          : null;

      // ----------------------------------------------------------
      // Latest check-out
      // ----------------------------------------------------------

      const mergedCheckOut =
        checkOuts.length > 0
          ? [...checkOuts].sort()[
              checkOuts.length - 1
            ]
          : null;

      // ----------------------------------------------------------
      // Regularization has highest priority
      // ----------------------------------------------------------

      const check_in =
        reg?.check_in ??
        mergedCheckIn;

      const check_out =
        reg?.check_out ??
        mergedCheckOut;

      // ----------------------------------------------------------
      // Sources
      // ----------------------------------------------------------

      const sources: AttendanceSourceTag[] =
        [];

      if (bio) {
        sources.push("Biometric");
      }

      if (trak) {
        sources.push("Trakola");
      }

      const hasRegularization =
        Boolean(reg) &&
        (
          reg?.check_in !== null ||
          reg?.check_out !== null
        );

      if (hasRegularization) {
        sources.push("Regularized");
      }

      // ----------------------------------------------------------
      // Working hours
      // ----------------------------------------------------------
      const working_hours =
        check_in && check_out
          ? this.diffHours(
              check_in,
              check_out,
            )
          : null;
      // ----------------------------------------------------------
      // Basic day status
      // ----------------------------------------------------------
      let status: CombinedDayStatus =
        "No Punches";
      if (
        check_in &&
        check_out
      ) {
        status = "Present";
      } else if (
        check_in ||
        check_out
      ) {
        status = "Incomplete";
      }
      // ----------------------------------------------------------
      // Push
      // ----------------------------------------------------------
      result.push({
        date,
        check_in,
        check_out,
        working_hours,
        sources,
        isRegularized:
          hasRegularization,
        status,
        finalStatus: null,
        matchedRule: null,
        lateMinutes: null,
        punch_count,
      });
    }
    // ============================================================
    // SORT DESCENDING
    // ============================================================

    return result.sort((a, b) =>
      a.date < b.date
        ? 1
        : a.date > b.date
          ? -1
          : 0,
    );
  }

  // =====================================================================
  // TIME DIFFERENCE
  // =====================================================================

  private diffHours(
    checkIn: string,
    checkOut: string,
  ): number {
    const [
      inHour,
      inMinute,
      inSecond = 0,
    ] = checkIn
      .split(":")
      .map(Number);

    const [
      outHour,
      outMinute,
      outSecond = 0,
    ] = checkOut
      .split(":")
      .map(Number);

    let inSeconds =
      inHour * 3600 +
      inMinute * 60 +
      inSecond;

    let outSeconds =
      outHour * 3600 +
      outMinute * 60 +
      outSecond;

    // ------------------------------------------------------------
    // Overnight shift
    // ------------------------------------------------------------

    if (outSeconds < inSeconds) {
      outSeconds += 24 * 60 * 60;
    }

    const differenceSeconds =
      outSeconds - inSeconds;

    return Math.round(
      (differenceSeconds / 3600) * 100,
    ) / 100;
  }
}

export const attendanceCombinedService =
  new AttendanceCombinedService();